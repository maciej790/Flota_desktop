--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'WIN1250';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE flota;
--
-- Name: flota; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE flota WITH TEMPLATE = template0 ENCODING = 'WIN1250' LOCALE_PROVIDER = libc LOCALE = 'Polish_Poland.1250';


ALTER DATABASE flota OWNER TO postgres;

\connect flota

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'WIN1250';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: osoby; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.osoby (
    id_osoby bigint NOT NULL,
    imie character varying NOT NULL,
    nazwisko character varying NOT NULL,
    pesel character varying NOT NULL,
    rola character varying NOT NULL,
    login character varying,
    haslo character varying
)
WITH (autovacuum_enabled='true');


ALTER TABLE public.osoby OWNER TO postgres;

--
-- Name: osoby_id_osoby_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.osoby_id_osoby_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.osoby_id_osoby_seq OWNER TO postgres;

--
-- Name: osoby_id_osoby_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.osoby_id_osoby_seq OWNED BY public.osoby.id_osoby;


--
-- Name: pojazdy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pojazdy (
    id_pojazdu bigint NOT NULL,
    marka character varying NOT NULL,
    model character varying NOT NULL,
    dane_serwisowe character varying,
    naped character varying NOT NULL,
    paliwo integer,
    status character varying NOT NULL,
    data_przegladu date NOT NULL,
    przebieg character varying
)
WITH (autovacuum_enabled='true');


ALTER TABLE public.pojazdy OWNER TO postgres;

--
-- Name: pojazdy_id_pojazdu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pojazdy_id_pojazdu_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pojazdy_id_pojazdu_seq OWNER TO postgres;

--
-- Name: pojazdy_id_pojazdu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pojazdy_id_pojazdu_seq OWNED BY public.pojazdy.id_pojazdu;


--
-- Name: wypozyczenia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wypozyczenia (
    id_wypozyczenia bigint NOT NULL,
    id_osoby bigint NOT NULL,
    id_pojazdu bigint NOT NULL,
    data_poczatek date NOT NULL,
    data_koniec date NOT NULL
)
WITH (autovacuum_enabled='true');


ALTER TABLE public.wypozyczenia OWNER TO postgres;

--
-- Name: wypozyczenia_id_wypozyczenia_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wypozyczenia_id_wypozyczenia_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wypozyczenia_id_wypozyczenia_seq OWNER TO postgres;

--
-- Name: wypozyczenia_id_wypozyczenia_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.wypozyczenia_id_wypozyczenia_seq OWNED BY public.wypozyczenia.id_wypozyczenia;


--
-- Name: zapytania; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.zapytania (
    id_zapytania bigint NOT NULL,
    id_osoby bigint NOT NULL,
    id_pojazdu bigint NOT NULL,
    data_poczatek date,
    data_koniec date,
    uzasadnienie character varying,
    decyzja boolean
)
WITH (autovacuum_enabled='true');


ALTER TABLE public.zapytania OWNER TO postgres;

--
-- Name: zapytania_id_zapytania_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.zapytania_id_zapytania_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zapytania_id_zapytania_seq OWNER TO postgres;

--
-- Name: zapytania_id_zapytania_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.zapytania_id_zapytania_seq OWNED BY public.zapytania.id_zapytania;


--
-- Name: osoby id_osoby; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.osoby ALTER COLUMN id_osoby SET DEFAULT nextval('public.osoby_id_osoby_seq'::regclass);


--
-- Name: pojazdy id_pojazdu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pojazdy ALTER COLUMN id_pojazdu SET DEFAULT nextval('public.pojazdy_id_pojazdu_seq'::regclass);


--
-- Name: wypozyczenia id_wypozyczenia; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wypozyczenia ALTER COLUMN id_wypozyczenia SET DEFAULT nextval('public.wypozyczenia_id_wypozyczenia_seq'::regclass);


--
-- Name: zapytania id_zapytania; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zapytania ALTER COLUMN id_zapytania SET DEFAULT nextval('public.zapytania_id_zapytania_seq'::regclass);


--
-- Data for Name: osoby; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.osoby (id_osoby, imie, nazwisko, pesel, rola, login, haslo) FROM stdin;
\.
COPY public.osoby (id_osoby, imie, nazwisko, pesel, rola, login, haslo) FROM '$$PATH$$/4867.dat';

--
-- Data for Name: pojazdy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pojazdy (id_pojazdu, marka, model, dane_serwisowe, naped, paliwo, status, data_przegladu, przebieg) FROM stdin;
\.
COPY public.pojazdy (id_pojazdu, marka, model, dane_serwisowe, naped, paliwo, status, data_przegladu, przebieg) FROM '$$PATH$$/4869.dat';

--
-- Data for Name: wypozyczenia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wypozyczenia (id_wypozyczenia, id_osoby, id_pojazdu, data_poczatek, data_koniec) FROM stdin;
\.
COPY public.wypozyczenia (id_wypozyczenia, id_osoby, id_pojazdu, data_poczatek, data_koniec) FROM '$$PATH$$/4871.dat';

--
-- Data for Name: zapytania; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.zapytania (id_zapytania, id_osoby, id_pojazdu, data_poczatek, data_koniec, uzasadnienie, decyzja) FROM stdin;
\.
COPY public.zapytania (id_zapytania, id_osoby, id_pojazdu, data_poczatek, data_koniec, uzasadnienie, decyzja) FROM '$$PATH$$/4873.dat';

--
-- Name: osoby_id_osoby_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.osoby_id_osoby_seq', 7, true);


--
-- Name: pojazdy_id_pojazdu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pojazdy_id_pojazdu_seq', 5, true);


--
-- Name: wypozyczenia_id_wypozyczenia_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.wypozyczenia_id_wypozyczenia_seq', 3, true);


--
-- Name: zapytania_id_zapytania_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.zapytania_id_zapytania_seq', 3, true);


--
-- Name: osoby osoby_pesel_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.osoby
    ADD CONSTRAINT osoby_pesel_key UNIQUE (pesel);


--
-- Name: osoby osoby_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.osoby
    ADD CONSTRAINT osoby_pkey PRIMARY KEY (id_osoby);


--
-- Name: pojazdy pojazdy_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pojazdy
    ADD CONSTRAINT pojazdy_pkey PRIMARY KEY (id_pojazdu);


--
-- Name: wypozyczenia wypozyczenia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wypozyczenia
    ADD CONSTRAINT wypozyczenia_pkey PRIMARY KEY (id_wypozyczenia, id_osoby, id_pojazdu);


--
-- Name: zapytania zapytania_id_zapytania_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zapytania
    ADD CONSTRAINT zapytania_id_zapytania_key UNIQUE (id_zapytania);


--
-- Name: zapytania zapytania_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zapytania
    ADD CONSTRAINT zapytania_pkey PRIMARY KEY (id_zapytania, id_osoby, id_pojazdu);


--
-- Name: wypozyczenia Relationship1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wypozyczenia
    ADD CONSTRAINT "Relationship1" FOREIGN KEY (id_osoby) REFERENCES public.osoby(id_osoby);


--
-- Name: wypozyczenia Relationship2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wypozyczenia
    ADD CONSTRAINT "Relationship2" FOREIGN KEY (id_pojazdu) REFERENCES public.pojazdy(id_pojazdu);


--
-- Name: zapytania Relationship3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zapytania
    ADD CONSTRAINT "Relationship3" FOREIGN KEY (id_osoby) REFERENCES public.osoby(id_osoby);


--
-- Name: zapytania Relationship4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zapytania
    ADD CONSTRAINT "Relationship4" FOREIGN KEY (id_pojazdu) REFERENCES public.pojazdy(id_pojazdu);


--
-- PostgreSQL database dump complete
--

